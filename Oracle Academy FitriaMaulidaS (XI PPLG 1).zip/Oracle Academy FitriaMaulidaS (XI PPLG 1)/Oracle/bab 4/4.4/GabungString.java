public class GabungString {
    public static void main(String[] args) {
        String s1 = "Halo ";
        String s2 = "Dunia!";
        String hasil = s1 + s2;
        System.out.println(hasil);
    }
}
