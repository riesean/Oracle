import java.util.Scanner;

public class SchoolTrip {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Masukkan total orang: ");
        int total = sc.nextInt();

        int bus = total / 45;
        int van = total % 45;

        System.out.println("Jumlah bus: " + bus);
        System.out.println("Jumlah orang naik van: " + van);

        sc.close();
    }
}
