public class StudentTest {
    public static void main(String[] args) {
        Student s1 = new Student("Lisa", "Palombo", "123456789", "Active");
        s1.displayInfo();
    }
}
