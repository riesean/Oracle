import java.util.Scanner;

public class OperasiMatriks {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int[][] a = new int[2][2];
        int[][] b = new int[2][2];

        System.out.println("Isi Matriks A:");
        baca(sc, a);
        System.out.println("Isi Matriks B:");
        baca(sc, b);

        char pilih;
        do {
            System.out.println("a. A+B | b. A-B | c. A*B | d. Keluar");
            pilih = sc.next().toLowerCase().charAt(0);
            if (pilih == 'a') tampil(hitung(a, b, 1));
            else if (pilih == 'b') tampil(hitung(a, b, 2));
            else if (pilih == 'c') tampil(hitung(a, b, 3));
        } while (pilih != 'd');
        sc.close();
    }

    static void baca(Scanner sc, int[][] m) {
        for (int i = 0; i < 2; i++)
            for (int j = 0; j < 2; j++) {
                System.out.print("[" + i + "][" + j + "]: ");
                m[i][j] = sc.nextInt();
            }
    }

    static int[][] hitung(int[][] a, int[][] b, int op) {
        int[][] h = new int[2][2];
        for (int i = 0; i < 2; i++)
            for (int j = 0; j < 2; j++) {
                if (op == 1) h[i][j] = a[i][j] + b[i][j];
                else if (op == 2) h[i][j] = a[i][j] - b[i][j];
                else h[i][j] = a[i][0] * b[0][j] + a[i][1] * b[1][j];
            }
        return h;
    }

    static void tampil(int[][] m) {
        for (int[] r : m) System.out.println(r[0] + " " + r[1]);
    }
}
