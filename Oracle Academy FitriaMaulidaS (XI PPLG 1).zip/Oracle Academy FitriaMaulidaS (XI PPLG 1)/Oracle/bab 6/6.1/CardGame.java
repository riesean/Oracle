import java.util.*;

class Card {
    String suit, name;
    int points;

    Card(int s, int n) {
        String[] suits = {"Clubs", "Diamonds", "Hearts", "Spades"};
        String[] names = {"Ace", "2", "3", "4", "5", "6", "7", "8", "9", "10", "Jack", "Queen", "King"};
        suit = suits[s - 1];
        name = names[n - 1];
        points = (n == 1) ? 11 : (n >= 11 ? 10 : n);
    }

    public String toString() { return name + " of " + suit; }
}

class Deck {
    ArrayList<Card> cards = new ArrayList<>();

    Deck() {
        for (int s = 1; s <= 4; s++)
            for (int n = 1; n <= 13; n++)
                cards.add(new Card(s, n));
    }

    void shuffle() { Collections.shuffle(cards); }
    Card draw() { return cards.remove(0); }
}

class Hand {
    ArrayList<Card> cards = new ArrayList<>();

    void add(Card c) { cards.add(c); }

    int totalPoints() {
        int total = 0, ace = 0;
        for (Card c : cards) {
            total += c.points;
            if (c.name.equals("Ace")) ace++;
        }
        while (total > 21 && ace > 0) {
            total -= 10;
            ace--;
        }
        return total;
    }
}

public class CardGame {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Deck deck = new Deck();
        deck.shuffle();
        Hand hand = new Hand();
        hand.add(deck.draw());
        hand.add(deck.draw());

        while (hand.cards.size() < 5 && hand.totalPoints() <= 21) {
            for (Card c : hand.cards) System.out.println(c);
            System.out.println("Poin: " + hand.totalPoints());
            System.out.print("Ambil lagi? (y/n): ");
            if (!sc.next().equalsIgnoreCase("y")) break;
            hand.add(deck.draw());
        }
        System.out.println("Poin akhir: " + hand.totalPoints());
        sc.close();
    }
}
