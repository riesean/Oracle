import java.util.Scanner;

public class RataRataTes {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int[] nilai = new int[5];
        int total = 0;

        for (int i = 0; i < nilai.length; i++) {
            System.out.print("Nilai ke-" + (i + 1) + ": ");
            nilai[i] = sc.nextInt();
            total += nilai[i];
        }

        double rata = (double) total / nilai.length;
        System.out.println("Rata-rata: " + rata);
        sc.close();
    }
}
