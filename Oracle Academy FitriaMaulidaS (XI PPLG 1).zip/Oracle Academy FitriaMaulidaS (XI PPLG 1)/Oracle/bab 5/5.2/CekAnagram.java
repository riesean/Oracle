import java.util.Arrays;
import java.util.Scanner;

public class CekAnagram {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Kata 1: ");
        String k1 = sc.nextLine().toLowerCase().replaceAll("[^a-z0-9]", "");
        System.out.print("Kata 2: ");
        String k2 = sc.nextLine().toLowerCase().replaceAll("[^a-z0-9]", "");

        char[] a = k1.toCharArray();
        char[] b = k2.toCharArray();
        Arrays.sort(a);
        Arrays.sort(b);

        System.out.println(Arrays.equals(a, b) ? "Anagram" : "Bukan anagram");
        sc.close();
    }
}
