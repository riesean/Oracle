import java.util.Scanner;

public class PesanRahasia {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String pesan = "";

        for (int i = 1; i <= 10; ) {
            System.out.print("Masukkan angka ke-" + i + ": ");
            int angka = sc.nextInt();

            switch (angka) {
                case 1: pesan += "D"; i++; break;
                case 2: pesan += "W"; i++; break;
                case 3: pesan += "E"; i++; break;
                case 4: pesan += "L"; i++; break;
                case 5: pesan += "H"; i++; break;
                case 6: pesan += "O"; i++; break;
                case 7: pesan += "R"; i++; break;
                default: System.out.println("Angka belum dikenal, coba lagi.");
            }
        }

        System.out.println("Pesan: " + pesan);
        sc.close();
    }
}
