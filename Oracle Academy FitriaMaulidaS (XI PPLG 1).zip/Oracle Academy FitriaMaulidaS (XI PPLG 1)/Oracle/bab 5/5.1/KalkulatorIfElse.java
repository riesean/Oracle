import java.util.Scanner;

public class KalkulatorIfElse {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Angka 1: ");
        double a = sc.nextDouble();
        System.out.print("Operator (+, -, *, /, %): ");
        char op = sc.next().charAt(0);
        System.out.print("Angka 2: ");
        double b = sc.nextDouble();

        if (op == '+') System.out.println("Hasil: " + (a + b));
        else if (op == '-') System.out.println("Hasil: " + (a - b));
        else if (op == '*') System.out.println("Hasil: " + (a * b));
        else if (op == '/') System.out.println(b != 0 ? "Hasil: " + (a / b) : "Tidak bisa dibagi nol.");
        else if (op == '%') System.out.println(b != 0 ? "Hasil: " + (a % b) : "Tidak bisa modulo nol.");
        else System.out.println("Operator tidak dikenal.");
        sc.close();
    }
}
