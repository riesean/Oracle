import java.util.Scanner;

public class FinalExam {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Rata-rata nilai: ");
        double average = sc.nextDouble();
        System.out.print("Jumlah absen: ");
        int daysAbsent = sc.nextInt();

        boolean exempt = (average >= 90 && daysAbsent <= 3) || (average >= 80 && daysAbsent == 0);
        if (exempt) {
            System.out.println("Dibebaskan dari ujian akhir.");
        } else {
            System.out.println("Harus ikut ujian akhir.");
        }
        sc.close();
    }
}
