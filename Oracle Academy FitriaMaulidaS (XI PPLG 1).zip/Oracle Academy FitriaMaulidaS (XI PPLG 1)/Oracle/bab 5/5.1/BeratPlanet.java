import java.util.Scanner;

public class BeratPlanet {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Berat di Bumi: ");
        double berat = sc.nextDouble();

        System.out.println("1. Merkurius 2. Venus 3. Mars 4. Jupiter 5. Saturnus 6. Uranus 7. Neptunus");
        System.out.print("Pilih: ");
        int pilih = sc.nextInt();

        String planet = "";
        double faktor = 0;

        switch (pilih) {
            case 1: planet = "Merkurius"; faktor = 0.38; break;
            case 2: planet = "Venus"; faktor = 0.91; break;
            case 3: planet = "Mars"; faktor = 0.38; break;
            case 4: planet = "Jupiter"; faktor = 2.36; break;
            case 5: planet = "Saturnus"; faktor = 0.92; break;
            case 6: planet = "Uranus"; faktor = 0.89; break;
            case 7: planet = "Neptunus"; faktor = 1.13; break;
            default: System.out.println("Pilihan tidak tersedia.");
        }

        if (faktor != 0) {
            System.out.println("Your weight on " + planet + " is " + (berat * faktor));
        }
        sc.close();
    }
}
