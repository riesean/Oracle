import java.util.Scanner;

public class PenerimaanMahasiswa {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Valedictorian/salutatorian (true/false): ");
        boolean peringkat = sc.nextBoolean();
        System.out.print("Jumlah siswa: ");
        int jumlahSiswa = sc.nextInt();
        System.out.print("GPA: ");
        double gpa = sc.nextDouble();
        System.out.print("SAT: ");
        int sat = sc.nextInt();

        boolean diterima = (peringkat && jumlahSiswa >= 1400)
                || (gpa >= 4.0 && sat >= 1100)
                || (gpa >= 3.5 && sat >= 1300)
                || (gpa >= 3.0 && sat >= 1500);

        System.out.println(diterima ? "Mahasiswa diterima." : "Mahasiswa belum memenuhi syarat.");
        sc.close();
    }
}
