import java.util.Scanner;

public class KebutuhanCat {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Tinggi: ");
        double tinggi = sc.nextDouble();
        System.out.print("Panjang: ");
        double panjang = sc.nextDouble();
        System.out.print("Lebar: ");
        double lebar = sc.nextDouble();

        double luas = 2 * tinggi * (panjang + lebar) + panjang * lebar;
        int max5 = (int) Math.ceil(luas / 1500.0);
        int best5 = 0, best1 = 0;
        double minBiaya = Double.MAX_VALUE;

        for (int e5 = 0; e5 <= max5; e5++) {
            double sisa = luas - e5 * 1500.0;
            int e1 = (sisa > 0) ? (int) Math.ceil(sisa / 300.0) : 0;
            double biaya = e5 * 15 + e1 * 4;
            if (biaya < minBiaya) {
                minBiaya = biaya;
                best5 = e5;
                best1 = e1;
            }
        }

        System.out.println("Luas: " + luas + " | Ember 5L: " + best5 + " | Ember 1L: " + best1 + " | Biaya: $" + minBiaya);
        sc.close();
    }
}
