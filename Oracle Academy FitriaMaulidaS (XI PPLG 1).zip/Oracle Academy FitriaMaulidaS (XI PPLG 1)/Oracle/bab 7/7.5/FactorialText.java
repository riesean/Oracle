public class FactorialText {
    public int num;

    public FactorialText(int num) { this.num = num; }

    public int getFactorial() {
        int fact = 1;
        for (int i = 1; i <= num; i++) fact *= i;
        return fact;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (int i = 1; i <= num; i++) {
            sb.append(i);
            if (i < num) sb.append(" * ");
        }
        return "Factorial: " + num + "! = " + sb + " = " + getFactorial();
    }

    public static void main(String[] args) {
        System.out.println(new FactorialText(10));
    }
}
