public class TestVehicle {
    public static void main(String[] args) {
        System.out.println("Manufacturer: " + Vehicle.MAKE);
        System.out.println("Number of vehicles manufactured: " + Vehicle.numVehicles);

        Vehicle v1 = new Vehicle("Vision");
        System.out.println(v1);

        Vehicle v2 = new Vehicle("Edict");
        System.out.println(v2);

        Vehicle.setMake("Seer");
        System.out.println(v1);

        Vehicle.Engine v3 = new Vehicle.Engine("Fortune");
        System.out.println(v3);
        System.out.println("Capacity: " + Vehicle.Engine.getCapacity() + "cc");
    }
}
