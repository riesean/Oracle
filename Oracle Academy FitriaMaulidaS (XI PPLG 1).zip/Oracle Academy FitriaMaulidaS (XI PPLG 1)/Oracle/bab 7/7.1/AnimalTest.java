class Animal {
    int weight, height;
    double speed;

    Animal() {
        weight = 50;
        height = 4;
        speed = 2;
    }

    Animal(int w, int h, int s) {
        weight = w;
        height = h;
        speed = s;
    }

    public double getTime(double miles) { return miles / speed; }
    public int getWeight() { return weight; }
    public int getHeight() { return height; }
    public double getSpeed() { return speed; }
}

public class AnimalTest {
    public static void main(String[] args) {
        Animal a1 = new Animal();
        Animal a2 = new Animal(70, 5, 4);
        System.out.println("Animal #1 speed: " + a1.getSpeed());
        System.out.println("Animal #2 speed: " + a2.getSpeed());
    }
}
