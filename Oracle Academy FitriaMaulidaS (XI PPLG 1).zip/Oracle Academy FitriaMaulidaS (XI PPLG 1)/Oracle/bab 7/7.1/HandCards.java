import java.util.*;

class Card {
    String suit, name;
    int points;

    Card(int s, int n) {
        String[] suits = {"Clubs", "Diamonds", "Hearts", "Spades"};
        String[] names = {"Ace", "2", "3", "4", "5", "6", "7", "8", "9", "10", "Jack", "Queen", "King"};
        suit = suits[s - 1];
        name = names[n - 1];
        points = (n == 1) ? 11 : (n >= 11 ? 10 : n);
    }

    public String toString() {
        return name + " of " + suit;
    }
}

public class HandCards {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ArrayList<Card> hand = new ArrayList<>();
        int total = 0;

        while (hand.size() < 5 && total <= 21) {
            Card c = new Card((int) (Math.random() * 4) + 1, (int) (Math.random() * 13) + 1);
            hand.add(c);
            total += c.points;
            System.out.println("Kartu: " + c + " | Total: " + total);
            if (hand.size() >= 5 || total > 21) break;
            System.out.print("Ambil lagi? (y/n): ");
            if (!sc.next().equalsIgnoreCase("y")) break;
        }
        sc.close();
    }
}