class StudentGpa {
    private String name;
    private int credits;
    private double gpa;
    private int qualityPoints;

    public StudentGpa(String name, int credits, int qualityPoints) {
        this.name = name;
        this.credits = credits;
        this.qualityPoints = qualityPoints;
        updateGpa();
    }

    public double getGpa() { return gpa; }

    public void addCourse(int newCredits, int newQualityPoints) {
        credits += newCredits;
        qualityPoints += newQualityPoints;
        updateGpa();
    }

    private void updateGpa() {
        gpa = credits > 0 ? (double) qualityPoints / credits : 0;
    }

    public String getName() { return name; }
}

public class StudentGpaTest {
    public static void main(String[] args) {
        StudentGpa mary = new StudentGpa("Mary Jones", 14, 46);
        StudentGpa john = new StudentGpa("John Stiner", 60, 173);
        StudentGpa ari = new StudentGpa("Ari Samala", 31, 69);

        System.out.println(mary.getName() + ": " + mary.getGpa());
        System.out.println(john.getName() + ": " + john.getGpa());
        System.out.println(ari.getName() + ": " + ari.getGpa());

        ari.addCourse(13, 52);
        System.out.println("IP Ari setelah ditambah: " + ari.getGpa());
    }
}
