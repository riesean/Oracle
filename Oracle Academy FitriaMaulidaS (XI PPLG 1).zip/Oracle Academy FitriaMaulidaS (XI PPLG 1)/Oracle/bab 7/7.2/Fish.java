public class Fish {
    String typeOfFish;
    int friendliness;

    public Fish() {
        typeOfFish = "Unknown";
        friendliness = 3;
    }

    public Fish(String t, int f) {
        typeOfFish = t;
        friendliness = f;
    }

    public int getFriendliness() { return friendliness; }

    public static Fish nicestFish(Fish f1, Fish f2) {
        return f1.getFriendliness() >= f2.getFriendliness() ? f1 : f2;
    }

    public static Fish nicestFish(Fish... list) {
        Fish best = list[0];
        for (Fish f : list) {
            if (f.getFriendliness() > best.getFriendliness()) best = f;
        }
        return best;
    }

    public static void main(String[] args) {
        Fish fish1 = new Fish("AngelFish", 5);
        Fish fish2 = new Fish("Guppy", 3);
        System.out.println(nicestFish(fish1, fish2).typeOfFish);
        System.out.println(nicestFish(fish1, fish2, new Fish()).typeOfFish);
    }
}
