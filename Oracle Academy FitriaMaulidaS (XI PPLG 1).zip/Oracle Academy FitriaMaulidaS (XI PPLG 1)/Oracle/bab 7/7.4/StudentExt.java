import java.util.Date;

class Person {
    private String firstName, middleName, lastName;
    private Date dateOfBirth;

    public Person(String firstName, String middleName, String lastName, Date dateOfBirth) {
        this.firstName = firstName;
        this.middleName = middleName;
        this.lastName = lastName;
        this.dateOfBirth = dateOfBirth;
    }

    public String getName() {
        return firstName + " " + middleName + " " + lastName;
    }

    public Date getDateOfBirth() {
        return dateOfBirth;
    }
}

public class StudentExt extends Person {
    private String nim, major, degree;
    private double gpa;
    private int expectedGraduationYear;

    public StudentExt(String firstName, String middleName, String lastName, Date dob,
                      String nim, String major, String degree, int expectedGraduationYear) {
        super(firstName, middleName, lastName, dob);
        this.nim = nim;
        this.major = major;
        this.degree = degree;
        this.expectedGraduationYear = expectedGraduationYear;
    }

    public void changeMajor(String newMajor) {
        major = newMajor;
    }

    public void calculateGpa(String[] grades) {
        double total = 0;
        for (String g : grades) {
            switch (g) {
                case "A": total += 4.0; break;
                case "A-": total += 3.67; break;
                case "B+": total += 3.33; break;
                case "B": total += 3.0; break;
                case "B-": total += 2.67; break;
                case "C+": total += 2.33; break;
                case "C": total += 2.0; break;
                case "D": total += 1.0; break;
                default: total += 0.0;
            }
        }
        if (grades.length > 0) {
            gpa = total / grades.length;
        }
    }

    public double getGpa() {
        return gpa;
    }
}