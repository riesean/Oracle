import java.applet.Applet;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;

public class DrawShapes extends Applet {
    Font font;
    Color darkColor;
    Color lightColor;
    Color backgroundColor;

    public void init() {
        font = new Font("Arial", Font.BOLD, 18);
        darkColor = Color.BLACK;
        lightColor = Color.WHITE;
        backgroundColor = Color.GRAY;
        setBackground(backgroundColor);
    }

    public void paint(Graphics g) {
        g.setFont(font);
        g.setColor(lightColor);
        g.drawString("DrawShapes", 20, 30);
        g.fillRect(20, 50, 120, 60);

        g.setColor(darkColor);
        g.drawOval(160, 50, 80, 80);
    }
}