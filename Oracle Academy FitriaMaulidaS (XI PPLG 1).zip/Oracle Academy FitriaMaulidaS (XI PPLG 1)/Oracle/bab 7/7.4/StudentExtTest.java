import java.util.Date;

public class StudentExtTest {
    public static void main(String[] args) {
        StudentExt s = new StudentExt(
            "Fitria", "Maulida", "S", new Date(),
            "12345", "PPLG", "SMK", 2027
        );
        System.out.println("Nama: " + s.getName());
        s.changeMajor("Rekayasa Perangkat Lunak");
        String[] nilai = {"A", "A-", "B+"};
        s.calculateGpa(nilai);
        System.out.println("GPA: " + s.getGpa());
    }
}